# API Usuarios - Taller Unidad 2

**Autor:** Pablo Esteban Santana Vidal

## Descripción
API REST sencilla para gestión de usuarios (registro, autenticación y CRUD). Implementada en Node.js + Express.

## Requisitos
- Node.js
- npm

## Instalación
```bash
git clone <TU_REPO_URL>
cd api-usuarios
npm install
cp .env.example .env
# Edita .env y coloca un JWT_SECRET seguro
npm run dev
```

## Endpoints
- `POST /api/usuarios` — Crear usuario  
  - Request:
  ```json
  { "nombre": "Juan", "email": "juan@example.com", "password": "123456" }
  ```
  - Response (201):
  ```json
  { "id":"...", "nombre":"Juan", "email":"juan@example.com", "fecha_creacion":"..." }
  ```

- `POST /api/auth/login` — Login (obtiene token)  
  - Request:
  ```json
  { "email":"juan@example.com","password":"123456" }
  ```
  - Response:
  ```json
  { "token": "..." }
  ```

- `GET /api/usuarios` — Listar (protegido, header Authorization: Bearer <token>)
- `GET /api/usuarios/:id` — Obtener por ID (protegido)
- `PUT /api/usuarios/:id` — Actualizar (protegido)
- `DELETE /api/usuarios/:id` — Eliminar (protegido)

## Cómo probar
Importa la colección Postman/Thunder Client incluida y sigue los pasos:
1. Crear usuario (POST /api/usuarios)
2. Hacer login (POST /api/auth/login) → copiar token
3. Probar GET /api/usuarios con header Authorization: Bearer <token>

## Notas
- Este proyecto usa almacenamiento en memoria (array). En producción usar DB (Postgres, Mongo, etc.).
- No subir `.env` al repositorio.
