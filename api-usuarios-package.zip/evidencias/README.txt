Guarda aquí las capturas y la colección Postman/Thunder Client exportada.
