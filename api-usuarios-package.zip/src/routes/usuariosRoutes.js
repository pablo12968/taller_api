const express = require('express');
const router = express.Router();
const { crearUsuario, listarUsuarios, obtenerUsuario, actualizarUsuario, eliminarUsuario } = require('../controllers/usuariosController');
const { verifyToken } = require('../middleware/authMiddleware');

router.post('/', crearUsuario);             // registro (sin token)
router.get('/', verifyToken, listarUsuarios); 
router.get('/:id', verifyToken, obtenerUsuario);
router.put('/:id', verifyToken, actualizarUsuario);
router.delete('/:id', verifyToken, eliminarUsuario);

module.exports = router;
