const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { usuarios, findByEmail, findById, createUser, updateUser, deleteUser } = require('../models/usuarioModel');

const crearUsuario = async (req, res) => {
  const { nombre, email, password } = req.body;
  if (!nombre || !email || !password) return res.status(400).json({ error: 'Faltan campos requeridos' });
  if (findByEmail(email)) return res.status(409).json({ error: 'Email ya registrado' });

  const hashed = await bcrypt.hash(password, 10);
  const nuevo = { id: uuidv4(), nombre, email, password: hashed, fecha_creacion: new Date().toISOString() };
  createUser(nuevo);
  const { password: pwd, ...publico } = nuevo;
  res.status(201).json(publico);
};

const listarUsuarios = (req, res) => {
  const list = usuarios.map(({ password, ...rest }) => rest);
  res.json(list);
};

const obtenerUsuario = (req, res) => {
  const u = findById(req.params.id);
  if (!u) return res.status(404).json({ error: 'Usuario no encontrado' });
  const { password, ...publico } = u;
  res.json(publico);
};

const actualizarUsuario = async (req, res) => {
  const u = findById(req.params.id);
  if (!u) return res.status(404).json({ error: 'Usuario no encontrado' });

  const { nombre, email, password } = req.body;
  if (email && email !== u.email && findByEmail(email)) return res.status(409).json({ error: 'Email ya registrado' });

  const update = {};
  if (nombre) update.nombre = nombre;
  if (email) update.email = email;
  if (password) update.password = await bcrypt.hash(password, 10);

  const updated = updateUser(req.params.id, update);
  const { password: pwd, ...publico } = updated;
  res.json(publico);
};

const eliminarUsuario = (req, res) => {
  const ok = deleteUser(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Usuario no encontrado' });
  res.json({ message: 'Usuario eliminado' });
};

module.exports = { crearUsuario, listarUsuarios, obtenerUsuario, actualizarUsuario, eliminarUsuario };
