const usuarios = [];

function findByEmail(email) {
  return usuarios.find(u => u.email === email);
}
function findById(id) {
  return usuarios.find(u => u.id === id);
}
function createUser(user) {
  usuarios.push(user);
  return user;
}
function updateUser(id, data) {
  const u = findById(id);
  if (!u) return null;
  Object.assign(u, data);
  return u;
}
function deleteUser(id) {
  const idx = usuarios.findIndex(u => u.id === id);
  if (idx === -1) return false;
  usuarios.splice(idx, 1);
  return true;
}

module.exports = { usuarios, findByEmail, findById, createUser, updateUser, deleteUser };
